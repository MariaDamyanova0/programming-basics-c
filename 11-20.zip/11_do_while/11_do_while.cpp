//Loop algorithm with postcondition

#include <iostream>
using namespace std;

int main() {
    int i = 1; 
    do {
        cout << i << endl;
        i++;
    } while (i <= 100); 

    return 0;
}
